import React from 'react'

const Crase = () => {
  return (
    <div>Craseff</div>
  )
}

export default Crase